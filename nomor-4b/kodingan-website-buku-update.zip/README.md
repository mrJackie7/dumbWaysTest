# Simple CRUD with Node.JS and MySQL

12 April 2021

## About This Project

Project ini adalah sebuah project pembelajaran mandiri lanjutan dari yang sebelumnya, detailnya nanti, karena ini udah larut malam :v

## Penjelasan isi dari project ini

### Penjelasan Singkat

project sederhana ini menggunakan Node.JS dengan bantuan pustaka Express.js sebagai back-end antara view dengan database. Dia juga menggunakan pustaka lain seperti Body-Parser sebagai middleware untuk nge-handle request dan response data, Handlebars (.hbs) sebagai view engine data dari Node.JS, dan MySQl supaya dari NodeJS bisa konek ke database menggunakan MySQL (berbeda dari PHP dan framework PHP lainnya, Node.JS yang bisa langsung konek ke MySQL). Untuk UI-nya digunakan Bootstrap v.4.6.0 (ga mw pake yg versi beta5.0.0 karena masih beta version) dan jQuery v.3.6.0.

Untuk bisa liat module apa aja yg bisa gw pake, bisa di check di package.json (ga gw .gitignore) dan kalo mw liat yang buat UI-nya, bisa diintip juga ke folder public. Ohh iya gw juga include file sql dari database yg gw gunain ini, jadi silahkan dicheck, ya ;-).
