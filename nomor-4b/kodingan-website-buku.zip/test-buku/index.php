<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <form id="add-book">
    <h2>Form Buku</h2>
    <label for="book_name">Nama Buku</label>
    <input type="text" name="book_name" id="book_name" required>
    <label for="category_id">Kategori</label>
    <input type="text" name="category_id" id="category_id" required>
    <label for="writer_id">Penulis</label>
    <input type="text" name="writer_id" id="writer_id" required>
    <label for="publication_year">Tahun Publikasi</label>
    <input type="text" name="publication_year" id="publication_year" required>
    <label for="img_url">Gambar</label>
    <input type="text" name="img_url" id="img_url" required>
    <input type="submit" value="Input">
  </form>
  <form id="add-writer">
    <h2>Form Penulis</h2>
    <label for="writer_name">Nama Penulis</label>
    <input type="text" name="writer_name" id="writer_name" required>
    <input type="submit" value="Input">
  </form>
  <form id="add-category">
    <h2>Form Kategori</h2>
    <label for="category_name">Kategori Baru</label>
    <input type="text" name="category_name" id="category_name" required>
    <input type="submit" value="Input">
  </form>
  <div id="content">
    <h1>Loading</h1>
  </div>
  <script src="./js/ajaxScript.js"></script>
</body>
</html>