//fungsi untuk mendapatkan data buku
const getBooks = () => {
  fetch('http://localhost:85/test-buku/php/get_books.php')
  .then(res => res.json())
  .then(data => {
    let outputBooks = `<h2>Your Data </h2>`
    data.forEach(function(book){
      outputBooks += `
        <div class='container-book'>
          <p>${book.book_name}</p>
          <p>${book.writer_name}</p>
          <p>${book.category_name}</p>
          <p>${book.publication_year}</p>
          <p>${book.img_url}</p>
          <button onclick='deleteBook(${book.id})'>Delete</button>
          <p>========================</p>
        </div>
      `
    })
    document.getElementById('content').innerHTML = outputBooks
  })
}; getBooks()

// function untuk add penulis
const addBook = document.getElementById('add-book')
addBook.addEventListener('submit', function(event){
  event.preventDefault()
  const formattedBookData = {
    bookName: this.book_name.value,
    categoryId: this.category_id.value,
    writerId: this.writer_id.value,
    publicationYear: this.publication_year.value,
    imgUrl: this.img_url.value,
  }
  postBookData(formattedBookData)
  window.location.reload()
})
// asyncronus funvtion untuk post data penulis
async function postBookData(formattedBookData) {
  const response = await fetch('http://localhost:85/test-buku/php/add_book.php', {
    method: 'POST',
    body: JSON.stringify(formattedBookData)
  })
  // Let's check if this has a problem.
  if(!response.ok) {
    console.log(`whoops ${response.status}`)
  }else{
    const data = await response.json()
    console.log("oke")
  }
}

// function untuk add penulis
const addWritter = document.getElementById('add-writer')
addWritter.addEventListener('submit', function(event){
  event.preventDefault()
  const formattedWriterData = {
    writerName: this.writer_name.value,
  }
  postWriterData(formattedWriterData)
  window.location.reload()
})
// asyncronus funvtion untuk post data penulis
async function postWriterData(formattedWriterData) {
  const response = await fetch('http://localhost:85/test-buku/php/add_writer.php', {
    method: 'POST',
    body: JSON.stringify(formattedWriterData)
  })
  // Let's check if this has a problem.
  if(!response.ok) {
    console.log(`whoops ${response.status}`)
  }else{
    const data = await response.json()
    console.log("oke")
  }
}

// function untuk add kategory
const addCategory = document.getElementById('add-category')
addCategory.addEventListener('submit', function(event){
  event.preventDefault()
  const formattedCategoryData = {
    categoryName: this.category_name.value,
  }
  postCategoryData(formattedCategoryData)
  window.location.reload()
})
// asyncronus funvtion untuk post data penulis
async function postCategoryData(formattedCategoryData) {
  const response = await fetch('http://localhost:85/test-buku/php/add_category.php', {
    method: 'POST',
    body: JSON.stringify(formattedCategoryData)
  })
  // Let's check if this has a problem.
  if(!response.ok) {
    console.log(`whoops ${response.status}`)
  }else{
    const data = await response.json()
    console.log("oke")
  }
}

// Fungsi delete book berdasarkan book_tb.id
const deleteBook = (bookId) => {
  // const bookId = document.getElementById('book-id').innerHTML
  let askDelete = confirm('Delete this?')
  if(askDelete == true){
    goDeleteBook(bookId)
    window.location.reload()
  }else{
    alert('canceled')
    window.location.reload()
  }
}

async function goDeleteBook(bookId){
  const response = await fetch(`http://localhost:85/test-buku/php/delete_book.php?idBook=${bookId}`)
  // Let's check if this has a problem.
  if(!response.ok) {
    console.log(`whoops ${response.status}`)
  }else{
    const data = await response.json()
    alert("success")
  }
}