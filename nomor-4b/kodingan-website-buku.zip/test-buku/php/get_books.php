<?php
include './connection.php';
$connet = openConnection();

header("Content-Type: application/json");

$sql = "SELECT book_tb.id, book_tb.book_name, category_tb.category_name, writer_tb.writter_name, book_tb.publication_year, book_tb.img_url FROM book_tb INNER JOIN category_tb on book_tb.category_id = category_tb.id INNER JOIN writer_tb on book_tb.writer_id = writer_tb.writer_id";
$res = $connet->query($sql);

$numRows = $res->num_rows;

if($numRows > 0){
  $data = array();
  while($row = $res->fetch_assoc()){
    $data[] = $row;
  }
  print json_encode($data);
}else{
  echo "";
}

closeConnection($connet);
?>