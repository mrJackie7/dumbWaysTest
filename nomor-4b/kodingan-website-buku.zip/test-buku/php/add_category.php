<?php
include './connection.php';
$connet = openConnection();

$data = json_decode(file_get_contents('php://input'), true);

$category_name = $data["categoryName"];

$sql = "INSERT INTO category_tb (category_name) VALUES ('$category_name')";

if($connet->query($sql) === FALSE){
  $data['err_msg'] = "Error insert record: " . $connet->error;
}else{
  $data['success'] = TRUE;
}

echo json_encode($data);
closeConnection($connet);
?>