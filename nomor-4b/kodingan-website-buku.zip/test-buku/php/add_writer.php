<?php
include './connection.php';
$connet = openConnection();

$data = json_decode(file_get_contents('php://input'), true);

$writer_name = $data["writerName"];

$sql = "INSERT INTO writer_tb (writter_name) VALUES ('$writer_name')";

if($connet->query($sql) === FALSE){
  $data['err_msg'] = "Error insert record: " . $connet->error;
}else{
  $data['success'] = TRUE;
}

echo json_encode($data);
closeConnection($connet);
?>