<?php
include './connection.php';
$connet = openConnection();

$data = json_decode(file_get_contents('php://input'), true);

$book_name = $data["bookName"];
$category_id = $data["categoryId"];
$writer_id = $data["writerId"];
$publication_year = $data["publicationYear"];
$img_url = $data["imgUrl"];

$sql = "INSERT INTO book_tb (book_name, category_id, writer_id, publication_year, img_url) VALUES ('$book_name', '$category_id', '$writer_id', '$publication_year', '$img_url')";

if($connet->query($sql) === FALSE){
  $data['err_msg'] = "Error insert record: " . $connet->error;
}else{
  $data['success'] = TRUE;
}

echo json_encode($data);
closeConnection($connet);
?>