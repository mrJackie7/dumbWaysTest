<?php
include './connection.php';
$connet = openConnection();

$book_id = $_GET["idBook"];

$sql = "DELETE from book_tb WHERE id = '$book_id'";

if($connet->query($sql) === FALSE){
  $data['err_msg'] = "Error insert record: " . $connet->error;
}else{
  $data['success'] = TRUE;
}

echo json_encode($data);

closeConnection($connet);
?>